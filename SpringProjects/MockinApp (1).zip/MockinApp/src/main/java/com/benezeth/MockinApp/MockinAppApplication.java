package com.benezeth.MockinApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockinAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockinAppApplication.class, args);
	}

}
